/*package pdf;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
 
import org.apache.pdfbox.pdmodel.PDDocument;
// this class has the main function of the Cli class
public class pdfff {
	Cli c= new Cli();
	public static void main(String[] args)  throws IOException {
			// Forms f = new Forms();
		Cli c= new Cli();
		switch (args[0]) { 
		
		case "help": c.help();break;
		 // example des arguments: 	addCheckBox 0 100 50 4   C:\\Users\\admin\\Desktop\\mm.pdf
	    // example des arguments: 	addCheckBox  numero_de_page x y  nombre_d'elements le chemin vers pdf
	    // description des arguments: 	addCheckBox (numero de page dont nous voulons ajouter l'element)=0 coordon�es (x=100) (y=50)  (nombre de checkBox voulu)=4   le chemin o� se trouve le PDF C:\\Users\\admin\\Desktop\\mm.pdf
		case "addCheckBox": c.afficherCheckbox(args.length, args[5], args[1], args[2], args[3], args[4]); break;
		// example des arguments: addRadioBox 0 100 500 4 C:\\Users\\admin\\Desktop\\mm.pdf t
		case "addRadioBox":c.afficherRadioBox(args.length, args[5], args[1], args[2], args[3], args[4], args[6]);break;
		// example des arguments: addTextField 0 50 50 140 180 C:\\Users\\admin\\Desktop\\mm.pdf
		case "addTextField": c.afficherTextField(args.length, args[5], args[1], args[2], args[3], args[4], args[6]); break;
		// example des arguments: addRadioBoxAll 0 10 30 6 C:\\Users\\admin\\Desktop\\cc.pdf c
		case "addRadioBoxAll": c.afficherRadioBoxAll(args.length, args[5], args[1], args[2], args[3], args[4], args[6]); break;
		//example des arguments: addCheckBoxall 0 40 80 6 C:\\Users\\admin\\Desktop\\bb.pdf
		case "addCheckBoxall": c.afficherCheckBoxall(args.length, args[5], args[1], args[2], args[3], args[4]); break;
		// example des arguments: addTextFieldAll 50 50 140 180 C:\\Users\\admin\\Desktop\\mm.pdf
		case  "addTextFieldAll": c.afficherTextFieldAll(args.length, args[5], args[1], args[2], args[3], args[4]); break;
		// example des arguments: addCheckBoxTo 0 1 40 80 6 C:\\Users\\admin\\Desktop\\bb.pdf
		case "addCheckBoxTo": 	c.afficherCheckBoxTo(args.length, args[5], args[1], args[2], args[3], args[4], args[6]);break;
		// example des arguments: addTextFieldTo 1 2 50 50 140 180 C:\\Users\\admin\\Desktop\\mm.pdf
		case "addTextFieldTo": 	c.afficherTextFieldTo(args.length, args[5], args[1], args[2], args[3], args[4], args[6], args[7]);break;
		//  example des arguments: addCombo 0 50 50 C:\\Users\\admin\\Desktop\\mm.pdf rouge bleu vert
		case "addCombo":    
			//checking the number of the arguments 
			if (args.length > 6) {
				List<String> displayValues = new ArrayList<String>();
			    Forms	f = new Forms(args[4]);
				 
					//filling displayValues(an array list) with values form the  args[] table 
					//this list values will be options in our combobox
				for (int i = 5; i < args.length;i++) {
					String v = args[i];
					displayValues.add(v);
				}
				// adding a combobox to the form f  
				//the combobox options are in diplayValues list
				f.combo(Integer.parseInt(args[1]), Integer.parseInt(args[2]), Integer.parseInt(args[3]), displayValues);

				f.closePdf(args[4]);
			} else
			{	System.out.println("  less arguments than expected/n/nhhhh"); c.help();}
			break;
			
			// exemple des arguments: addComboAll 50 50 140 180 C:\\Users\\admin\\Desktop\\mm.pdf nn kk ll
				case "addComboAll":
					if (args.length > 7) {
					Forms	f = new Forms(args[5]);
						PDDocument doc = PDDocument.load(new File(args[5]));
						int count = doc.getNumberOfPages();
						List<String> displayValues = new ArrayList<String>();
						for (int i = 6; i <args.length; i++) {
							String v = args[i];
							displayValues.add(v);
						}
						for (int j = 0; j < count; j++) {
							f.combo(j, Integer.parseInt(args[1]), Integer.parseInt(args[2]), displayValues);
							 
						}
						f.closePdf(args[5]);
					} else
					{	System.out.println(" more or less arguments than expected\n\n"); c.help();}
					break;
		 
				case "changeTitle" : if (args.length == 3) {
				Forms	f = new Forms(args[2]);
					f.changeTitle(args[1]);
					System.out.println(" out");
					f.closePdf(args[2]);
				} else
				{	System.out.println(" more or less arguments than expected\n\nnhhhh"); c.help();}
				break;
				case"changeAuthor": if (args.length==3) {
			Forms		f = new Forms(args[2]);
					f.changeAuthor(args[1]);
					f.closePdf(args[2]);
				} else
				{	System.out.println(" more or less arguments than expected/n/nhhhh"); c.help();}
				break;
					default : c.help();


			 

			 
			 

			// addComboTo 1 3 50 50 C:\\Users\\admin\\Desktop\\mm.pdf nn kk ll
			/*
			 * if (args[0].equals("addComboTo")) { if (args.length >= 7) { f = new
			 * Forms(args[5]); PDDocument doc = PDDocument.load(new File(args[5])); int
			 * count = doc.getNumberOfPages(); int n = args.length; int
			 * j=Integer.parseInt(args[2]); if(j<=count) { int k=Integer.parseInt(args[1]);
			 * List<String> displayValues = new ArrayList<String>(); int i=0; String v="";
			 * System.out.println(args.length); for ( i = 6; i < n; i++) { v = args[i];
			 * System.out.println(args[i]); displayValues.add(v); }
			 * 
			 * for ( i = k; i <= j; i++) { f.combo( j, Integer.parseInt(args[3]),
			 * Integer.parseInt(args[4]), displayValues);
			 * System.out.println("goooooooooooooooooooooood"); } f.closePdf(args[5]); }
			 * else System.out.println("pdf only have " +count+ " pages\n"); } else
			 * System.out.println(" more or less arguments than expected"); }
			 */

		 
		
			 
		

/*
	


}}}*/