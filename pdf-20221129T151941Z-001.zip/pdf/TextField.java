
package pdf;
import java.io.IOException;

import org.apache.pdfbox.cos.COSDictionary;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.graphics.color.PDColor;
import org.apache.pdfbox.pdmodel.graphics.color.PDDeviceRGB;
import org.apache.pdfbox.pdmodel.interactive.annotation.PDAnnotationWidget;
import org.apache.pdfbox.pdmodel.interactive.annotation.PDAppearanceCharacteristicsDictionary;
import org.apache.pdfbox.pdmodel.interactive.form.PDAcroForm;
import org.apache.pdfbox.pdmodel.interactive.form.PDTextField;


public class TextField {
	public int page ;
	public float x ;
	public float y ;
	public float width ;
	public float height ;
	PDDocument document;
	PDAcroForm form;
	
	
	public TextField(int page, float x ,float y,float width, float height ,PDDocument document,
	PDAcroForm form) {
		this.page=page;
		this.x=x;
		this.y=y;
		this.height=height;
		this.width=width;
		this.document=document;
		this.form=form;
	}
	
	public TextField(int page, float x ,float y) {
		this.page=page;
		this.x=x;
		this.y=y;
	}
	
	
	public void makeTA() throws IOException {
		//add Text Field
        PDTextField textField = new PDTextField(form);
        textField.setPartialName("textField");

        //setting form field default appearance settings
        
        String defaultAppearance = "/Helv 12 Tf 0 0 1 rg";
        textField.setDefaultAppearance(defaultAppearance);

        form.getFields().add(textField);
		//set text zone
		PDAnnotationWidget widget = textField.getWidgets().get(0);
		PDRectangle rect = new PDRectangle(x,y,width,height);
		widget.setRectangle(rect);
		widget.setPage(document.getPage(page));
		//set format
        PDAppearanceCharacteristicsDictionary fieldAppearance = new PDAppearanceCharacteristicsDictionary(new COSDictionary());
        fieldAppearance.setBorderColour(new PDColor(new float[]{0,0,0}, PDDeviceRGB.INSTANCE));
        fieldAppearance.setBackground(new PDColor(new float[]{1,1,1}, PDDeviceRGB.INSTANCE));
        widget.setAppearanceCharacteristics(fieldAppearance);
        
         //set a default value (aka: place holder)
        PDPage p = document.getPage(page);
        widget.setPrinted(true);
        p.getAnnotations().add(widget);
        textField.setValue("enter text here");
        
	}


}
