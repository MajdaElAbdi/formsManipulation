import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.apache.pdfbox.cos.COSDictionary;
import org.apache.pdfbox.cos.COSName;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle; 
import org.apache.pdfbox.pdmodel.graphics.color.PDColor;
import org.apache.pdfbox.pdmodel.graphics.color.PDDeviceRGB;
import org.apache.pdfbox.pdmodel.interactive.annotation.PDAnnotationWidget;
import org.apache.pdfbox.pdmodel.interactive.annotation.PDAppearanceCharacteristicsDictionary;
import org.apache.pdfbox.pdmodel.interactive.annotation.PDAppearanceDictionary;
import org.apache.pdfbox.pdmodel.interactive.annotation.PDAppearanceEntry;
import org.apache.pdfbox.pdmodel.interactive.annotation.PDAppearanceStream;
import org.apache.pdfbox.pdmodel.interactive.annotation.PDBorderStyleDictionary;
import org.apache.pdfbox.pdmodel.interactive.form.PDAcroForm;
import org.apache.pdfbox.pdmodel.interactive.form.PDRadioButton;
 
public class RadioButton {
	 private PDAcroForm acroForm;
	 private PDDocument document;
	 private List<String> options;
	 private PDPage page;
	 private int x;
	 private int y;
	 private String t;
	  public RadioButton() {
		 	
	}
	 
	public    RadioButton(PDAcroForm acroForm,PDDocument document,List<String> options,PDPage page,int x,int y,String t)	throws IOException
		{
		document.getDocumentCatalog().setAcroForm(acroForm);
	 
		PDRadioButton radioButton = new PDRadioButton(acroForm);

	 
		radioButton.setPartialName("MyRadioButton"+t);
		//getting the RadioButton group values from options 
		radioButton.setExportValues(options);
//set the  Border and Background color of the radioButton
		PDAppearanceCharacteristicsDictionary appearanceCharacteristics = new PDAppearanceCharacteristicsDictionary(
				new COSDictionary());
		appearanceCharacteristics.setBorderColour(new PDColor(new float[] { 0, 0, 0 }, PDDeviceRGB.INSTANCE));
		appearanceCharacteristics.setBackground(new PDColor(new float[] {1, 1, 1 }, PDDeviceRGB.INSTANCE));
		
//creating the  RadioButton
		List<PDAnnotationWidget> widgets = new ArrayList<PDAnnotationWidget>();
	for (int i = 0; i < options.size(); i++) {
	//create widget	 
			PDAnnotationWidget widget = new PDAnnotationWidget();
			//40 : the space between 2 RadioBoxs
			widget.setRectangle(new PDRectangle(x, PDRectangle.A4.getHeight() -50-y -i * 30, 20, 20));
			 //adding the color  to the widget
			widget.setAppearanceCharacteristics(appearanceCharacteristics);
			// setting the borders
			PDBorderStyleDictionary borderStyleDictionary = new PDBorderStyleDictionary();
			borderStyleDictionary.setWidth(2);
			borderStyleDictionary.setStyle(PDBorderStyleDictionary.STYLE_SOLID);
			//adding the borders to the widget  
			widget.setBorderStyle(borderStyleDictionary);
			widget.setPage(page);

			
			COSDictionary apNDict = new COSDictionary();
			apNDict.setItem(COSName.Off, createAppearanceStream(document, widget, false));
			apNDict.setItem(options.get(i), createAppearanceStream(document, widget, true));
//set appearance of the widget
			
			PDAppearanceDictionary appearance = new PDAppearanceDictionary();
			PDAppearanceEntry appearanceNEntry = new PDAppearanceEntry(apNDict);
			appearance.setNormalAppearance(appearanceNEntry);
			widget.setAppearance(appearance);
			//make the button vivsible
			widget.setAppearanceState("Off");  
			widgets.add(widget);
			page.getAnnotations().add(widget);
		}
	//adding the radioButton Group to the acroform
		radioButton.setWidgets(widgets);
     	acroForm.getFields().add(radioButton);
     	radioButton.setValue("T0");
 
	}

	private static PDAppearanceStream createAppearanceStream(final PDDocument document, PDAnnotationWidget widget,
			boolean on) throws IOException {
		
	//	 create a contentStream
		PDRectangle rect = widget.getRectangle();
		PDAppearanceStream onAP = new PDAppearanceStream(document);
		onAP.setBBox(new PDRectangle(rect.getWidth(), rect.getHeight()));
		PDPageContentStream onAPCS = new PDPageContentStream(document, onAP);
//getting the colors of the widget
		PDAppearanceCharacteristicsDictionary appearanceCharacteristics = widget.getAppearanceCharacteristics();
		PDColor backgroundColor = appearanceCharacteristics.getBackground();
		PDColor borderColor = appearanceCharacteristics.getBorderColour();
	//setting  the line width and the color  of the contentStream
		float lineWidth = getLineWidth(widget);
		onAPCS.setLineWidth(lineWidth); // border style (dash) ignored
		onAPCS.setNonStrokingColor(backgroundColor);
		 
		float radius = Math.min(rect.getWidth() / 2, rect.getHeight() / 2);
		//draw the outside circle
		drawCircle(onAPCS, rect.getWidth() / 2, rect.getHeight() / 2, radius);
		onAPCS.fill();
		onAPCS.setStrokingColor(borderColor);

		//stroke the path   
		drawCircle(onAPCS, rect.getWidth() / 2, rect.getHeight() / 2, radius - lineWidth / 2);
		onAPCS.stroke();
		if (on) {
			//draw the inside circle
			onAPCS.setNonStrokingColor(0f);
			drawCircle(onAPCS, rect.getWidth() / 2, rect.getHeight() / 2, (radius - lineWidth) / 2);
			onAPCS.fill();
		}

		onAPCS.close();
		return onAP;
	}
//getting the widget border style
	static float getLineWidth(PDAnnotationWidget widget) {
		PDBorderStyleDictionary bs = widget.getBorderStyle();
		if (bs != null) {
			return bs.getWidth();
		}
		return 1;
	}

	
//painting circle
	//this method doesn't draw a perfect circle  but it looks close to perfect
	static void drawCircle(PDPageContentStream cs, float x, float y, float r) throws IOException
    {
	         
	        float magic = r * 0.551784f;
	        cs.moveTo(x, y + r);
	        cs.curveTo(x + magic, y + r, x + r, y + magic, x + r, y);
	        cs.curveTo(x + r, y - magic, x + magic, y - r, x, y - r);
	        cs.curveTo(x - magic, y - r, x - r, y - magic, x - r, y);
        cs.curveTo(x - r, y + magic, x - magic, y + r, x, y + r);
	        cs.closePath();
	    }
	}