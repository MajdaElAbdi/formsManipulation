import java.io.IOException;
import java.util.List;

import org.apache.pdfbox.cos.COSBase;
import org.apache.pdfbox.cos.COSDictionary;
import org.apache.pdfbox.cos.COSName;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.graphics.color.PDColor;
import org.apache.pdfbox.pdmodel.graphics.color.PDDeviceRGB;
import org.apache.pdfbox.pdmodel.interactive.annotation.PDAnnotationWidget;
import org.apache.pdfbox.pdmodel.interactive.annotation.PDAppearanceCharacteristicsDictionary;
import org.apache.pdfbox.pdmodel.interactive.annotation.PDAppearanceDictionary;
import org.apache.pdfbox.pdmodel.interactive.annotation.PDAppearanceEntry;
import org.apache.pdfbox.pdmodel.interactive.annotation.PDBorderStyleDictionary;
import org.apache.pdfbox.pdmodel.interactive.form.PDAcroForm;
import org.apache.pdfbox.pdmodel.interactive.form.PDCheckBox;

public class CheckBox
{private PDAcroForm acroForm;
private PDDocument document;
private PDPage page;
private float x;
private float y;
private String s;
    public CheckBox(){
    }

   
     
    public   CheckBox (float x ,float y, String s, PDPage page, PDDocument document, PDAcroForm acroForm ) throws IOException{
       
   
    PDCheckBox checkbox = new PDCheckBox(acroForm);
 box(x,y,s,checkbox,page ,document,acroForm);        
   
   
   
    }
         public static  void box(float x ,float y, String s,PDCheckBox checkbox, PDPage page, PDDocument document, PDAcroForm acroForm ) throws IOException{
           
            PDRectangle rect = new PDRectangle(x, PDRectangle.A4.getHeight()-50-y,20, 20);
            checkbox.setPartialName(s);
            
            //create a  widget  
            PDAnnotationWidget widget = checkbox.getWidgets().get(0);
            widget.setPage(page);
            widget.setRectangle(rect);
            widget.setPrinted(true);
           // set appearance
           PDAppearanceCharacteristicsDictionary appearanceCharacteristics = new PDAppearanceCharacteristicsDictionary(new COSDictionary());
            appearanceCharacteristics.setBorderColour(new PDColor(new float[]{0, 0, 0}, PDDeviceRGB.INSTANCE));
            appearanceCharacteristics.setBackground(new PDColor(new float[]{1, 1, 0}, PDDeviceRGB.INSTANCE));
            // 8 = cross; 4 = checkmark; H = star; u = diamond; n = square, l = dot
            appearanceCharacteristics.setNormalCaption("4");
            widget.setAppearanceCharacteristics(appearanceCharacteristics);
            
       //An appearance dictionary  specifying how the annotation shall be presented visually on the pag  
           PDAppearanceDictionary ap = new PDAppearanceDictionary();
            widget.setAppearance(ap);
           
        //add the checkBox to the form
            page.getAnnotations().add(checkbox.getWidgets().get(0));
            acroForm.getFields().add(checkbox);
            checkbox.unCheck();
            
        }

 

		 
}