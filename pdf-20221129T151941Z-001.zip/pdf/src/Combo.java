
 
import java.io.IOException;
import java.util.ArrayList;

import java.util.List;
 
import org.apache.pdfbox.cos.COSName;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
 
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
 
import org.apache.pdfbox.pdmodel.interactive.annotation.PDAnnotationWidget;
 
import org.apache.pdfbox.pdmodel.interactive.form.PDAcroForm;
 
import org.apache.pdfbox.pdmodel.interactive.form.PDComboBox;
import org.apache.pdfbox.pdmodel.font.PDFont;

 
import org.apache.pdfbox.pdmodel.PDResources;
 
public class Combo
{ private PDAcroForm acroForm;
private PDDocument document;
private List<String>  displayValues;
private PDPage page;
private int x;
private int y;
private List<String> exportValues;
	
	public Combo() {}

    public Combo(List<String> exportValues,List<String> displayValues,PDDocument document,PDPage page, PDAcroForm acroForm,int x,int y )
    {

        PDFont font = PDType1Font.HELVETICA;
        
        float fontSize = 12;
        //create new combo
        PDComboBox comboBox = new PDComboBox(acroForm);
        comboBox.setPartialName("test");

 //set appearance
        String defaultAppearanceString = "/Helv " + fontSize + " Tf "
                + 0 + " " + 0 + " " + 0 + " rg";
        comboBox.setDefaultAppearance(defaultAppearanceString);

        PDAnnotationWidget widget = new PDAnnotationWidget();
        widget.setRectangle(new PDRectangle(x,  PDRectangle.A4.getHeight()-50-y, 100, 20));
        widget.setAnnotationFlags(4);
        widget.setPage(page);
        widget.setParent(comboBox);      
 // displaysValues  :options that will appear when we will click into the comboBox
        comboBox.setOptions(exportValues, displayValues);

        List<PDAnnotationWidget> widgets = new ArrayList<>();
        widgets.add(widget);
        try
        {
            page.getAnnotations().add(widget);
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }

        comboBox.setWidgets(widgets);

        // add the comboBox to the acroForm
        acroForm.getFields().add(comboBox);
        document.getDocumentCatalog().setAcroForm(acroForm);
        PDResources dr = new PDResources();
        dr.put(COSName.getPDFName("Helv"), font);
        acroForm.setDefaultResources(dr);
 
    }
}