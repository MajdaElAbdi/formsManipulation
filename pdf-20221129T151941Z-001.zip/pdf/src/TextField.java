import java.io.IOException;

import org.apache.pdfbox.cos.COSDictionary;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.graphics.color.PDColor;
import org.apache.pdfbox.pdmodel.graphics.color.PDDeviceRGB;
import org.apache.pdfbox.pdmodel.interactive.annotation.PDAnnotationWidget;
import org.apache.pdfbox.pdmodel.interactive.annotation.PDAppearanceCharacteristicsDictionary;
import org.apache.pdfbox.pdmodel.interactive.form.PDAcroForm;
import org.apache.pdfbox.pdmodel.interactive.form.PDTextField;


public class TextField {
/*A text field is a box or space for text fill-in data entered from a keyboard.
* The text may be restricted to a single line or may be permitted to span multiple lines
*/
public int page ;
public float x ;
public float y ;
public float width ;
public float height ;
PDDocument document;// This is the in-memory representation of the PDF document.
PDAcroForm form;// An interactive form

//TextField constructor with all arguments
public TextField(int page, float x ,float y,float width, float height ,PDDocument document, PDAcroForm form) {
this.page=page;
this.x=x;
this.y=y;
this.height=height;
this.width=width;
this.document=document;
this.form=form;
}

//TextField constructor with page nbre and x,y coordinates
public TextField(int page, float x ,float y) {
this.page=page;
this.x=x;
this.y=y;
}

//build and display a Text Zone in the pdf
public void makeTA() throws IOException {
//add Text Field
        PDTextField textField = new PDTextField(form);// construct a textField for the PDtextField class in Apache pdfBox
        textField.setPartialName("textField"); // set the element

        //setting form field default appearance settings
       
        String defaultAppearance = "/Helv 12 Tf 0 0 1 rg";
        textField.setDefaultAppearance(defaultAppearance);

        //add the textField to the form
        form.getFields().add(textField);
       
//set text zone
PDAnnotationWidget widget = textField.getWidgets().get(0);
PDRectangle rect = new PDRectangle(x, PDRectangle.A4.getHeight() -50-y,width,height);
widget.setRectangle(rect);
widget.setPage(document.getPage(page));

//set appearance
        PDAppearanceCharacteristicsDictionary fieldAppearance = new PDAppearanceCharacteristicsDictionary(new COSDictionary());
        fieldAppearance.setBorderColour(new PDColor(new float[]{0,0,0}, PDDeviceRGB.INSTANCE));
        fieldAppearance.setBackground(new PDColor(new float[]{1,1,1}, PDDeviceRGB.INSTANCE));
        widget.setAppearanceCharacteristics(fieldAppearance);
       
         //set a default value ( place holder)
        PDPage p = document.getPage(page);
        widget.setPrinted(true);
        p.getAnnotations().add(widget);
        textField.setValue("enter text here");
       
}


}

