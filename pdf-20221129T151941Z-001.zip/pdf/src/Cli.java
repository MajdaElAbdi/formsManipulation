import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.io.File;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.interactive.form.PDAcroForm;

public class Cli {
	//create a form
	static Forms f = new Forms();

	public Cli()
{}
	 
	// method

//help1
	public static void help() {
		System.out.println("pdform <option> <option parameteres> <pdf path> \n" + "possible options include : \n"
				+ "addTextField int(pageNumber) int(x) int(y)  int(width) int(height) string(path) \n"
				+"addTextFieldAll int(x) int(y)  int(width) int(height) string(path) \n"
				+"addTextFieldTo int(BeginPageNumber) int(EndPageNumber) int(x) int(y)  int(width) int(height) string(path) \n"
				+ "addCheckBox int(pageNumber) int(x) int(y) int(nbrButton)  string(path)\n"
				+ "addCheckBoxAll int(x) int(y) int(nbrButton)  string(path)\n"
				+ "addCheckBoxTo int(BeginPageNumber) int(EndPageNumber) int(x) int(y) int(nbrButton)  string(path)\n"
				+ "addRadioBox int(pageNumber) int(x) int(y) int(totalButtonNum) string(path) \n"
				+ "addRadioBoxAll int(x) int(y) int(totalButtonNum) string(path) \n"
				+ "addCombo int(pageNumber) int(x) int(y) int( nbr de ligne de la liste combo) string(path) \n"
				+"addComboAll   int(x) int(y) int( nbr de ligne de la liste combo) string(path) \n"
				+"changeAuthor Sting(name) \n"
				+"changeTitle Sting(title) \n"
				+ "note : Measurement units inside a PDF are in points \n" +   "0------600 \n"+  "| \n" + "| pdf page dim\n"
				+ "| \n"+"700 \n");
	}
	//ajouter un groupe de checkBox
	static void afficherCheckbox(int longueur, String arg5, String arg1, String arg2, String arg3, String arg4)
			throws IOException {
		// check the number of the arguments
		if (longueur == 6) {
			// create a form in the pdf wich is located in the path arg5
			f = new Forms(arg5);
// add the checkbox to the form
			// numero_page=Integer.parseInt(arg1), x=Integer.parseInt(arg2),y=Integer.parseInt(arg3), nombre_de_bouton=Integer.parseInt(arg4)
			f.checkBox(Integer.parseInt(arg1), Integer.parseInt(arg2), Integer.parseInt(arg3), Integer.parseInt(arg4));
			f.closePdf(arg5);
			System.out.println(arg4+" CheckBoxs have been added to  page number"+arg1 +" of the pdf");
		}
		
		// check the number of the arguments
		if (longueur < 6)
			System.out.println("less arguments than expected (checkBox)");
		if (longueur > 6)
			System.out.println(" more arguments than expected (checkBox)");
	}
	//ajouter un groupe de RadioButton
	static void afficherRadioBox(int longueur, String arg5, String arg1, String arg2, String arg3, String arg4,
			String arg6) throws IOException {
		// check the number of the arguments
		if (longueur == 7) {
			// create a form in the pdf wich is located in the path arg5
			f = new Forms(arg5);
			// add the radioBox to the form
			//numero_page=Integer.parseInt(arg1),x=Integer.parseInt(arg2) ,y=Integer.parseInt(arg3),nombre_de_bouton=Integer.parseInt(arg4), ButtonGroupName=arg6
			f.radioButton(Integer.parseInt(arg1), Integer.parseInt(arg2), Integer.parseInt(arg3),
					Integer.parseInt(arg4), arg6);
			//close the pdf
			f.closePdf(arg5);
			System.out.println(arg4+" radioButtons have been added to  page number"+arg1  +"of the pdf");
		} else 
			System.out.println(" more or less arguments than expected");
	}
	//ajouter un groupe de RadioButton dans chaque page de pdf
	static void afficherRadioBoxAll(int longueur, String arg4, String arg1, String arg2, String arg3, String arg5) throws IOException {
		// check the number of the arguments
		if (longueur == 6) {
			f = new Forms(arg4);
			//get the  number of the pages of the pdf
			PDDocument doc = PDDocument.load(new File(arg4));
			int count = doc.getNumberOfPages();
//add the buttonn group to every single page of the pdf
			for (int i = 0; i < count; i++) {
				System.out.println(arg5);
				//numero_page=i,x=Integer.parseInt(arg1) ,y=Integer.parseInt(arg2),nombre_de_bouton=Integer.parseInt(arg3), ButtonGroupName=arg5
				f.radioButton(i, Integer.parseInt(arg1), Integer.parseInt(arg2), Integer.parseInt(arg3), arg5);			 
			} 
			System.out.println(arg3+" radioButtons have been added to  page number"+arg1+" of the pdf");
			f.closePdf(arg4);
		} else
			System.out.println(" more or less arguments than expected");
	}
	//ajouter un groupe de  checkBox dans chaque page de pdf
	static void afficherCheckBoxall(int longueur, String arg4, String arg1, String arg2, String arg3)
			throws IOException {
	
		// check the number of the arguments
		if (longueur == 5) {
			f = new Forms(arg4);
			PDDocument doc = PDDocument.load(new File(arg4));
			int count = doc.getNumberOfPages();
			// add the checkBox to the form
			for (int i = 0; i < count; i++) {
				// numero_page=i, x=Integer.parseInt(arg1),y=Integer.parseInt(arg2), nombre_de_bouton=Integer.parseInt(arg3)
				f.checkBox(i, Integer.parseInt(arg1), Integer.parseInt(arg2), Integer.parseInt(arg3));
 
			}
			System.out.println(arg3+" CheckBoxs have been added to every single page of the pdf");
			f.closePdf(arg4);
		} else
			System.out.println(" more or less arguments than expected");
	}
	
	
	// addCheckTo ajoute un groupe de checkBox dans un intervalle de pages d'un pdf.  
			//EX: l'ajout d'un groupe de checkbox de la page deux � la page quatre
	static void afficherCheckBoxTo(int longueur, String arg5, String arg1, String arg2, String arg3, String arg4,
			String arg6) throws IOException {
		// check the number of the arguments
		if (longueur == 7) {
			f = new Forms(arg6);
			//first page 
			int firstpage = Integer.parseInt(arg1);
			//the last page 
			int lastpage = Integer.parseInt(arg2);
			
			//l'ajout un groupe de checkBox dans un intervalle de pages
			for (int i = firstpage; i <=lastpage; i++) {
				// numero_page=i, x=Integer.parseInt(arg3),y=Integer.parseInt(arg4), nombre_de_bouton=Integer.parseInt(arg5)
	f.checkBox(i, Integer.parseInt(arg3), Integer.parseInt(arg4), Integer.parseInt(arg5));
				 
			}
			System.out.println(arg3+" CheckBoxs have been added to  page number"+arg1 +"until page number"+arg2+ "of the pdf");
			f.closePdf(arg6);
		} else
			System.out.println(" more or less arguments than expected");
	}

	
	  //l'ajout d'un TextField � une page d'un Pdf
	static void afficherTextField(int longueur, String arg5, String arg1, String arg2, String arg3, String arg4,
			String arg6) throws IOException {
		// check the number of the arguments
		if (longueur == 7) {
			f = new Forms(arg6);
			//l'ajout  de TextField � form
			// numero_page=Integer.parseInt(arg1), x=Integer.parseInt(arg2) ,y=Integer.parseInt(arg3),width=Integer.parseInt(arg4),   heigh=Integer.parseInt(arg5)
			f.tField(Integer.parseInt(arg1), Integer.parseInt(arg2), Integer.parseInt(arg3), Integer.parseInt(arg4),
					Integer.parseInt(arg5));
			f.closePdf(arg6);
			System.out.println(" a TextField has been added to the page number"+arg1+ " of the pdf");
		} else
			System.out.println(" more or less arguments than expected");
	}
  
	 //ajouter un  textfield dans chaque page de pdf
	
	static void afficherTextFieldAll(int longueur, String arg5, String arg1, String arg2, String arg3, String arg4)
			throws IOException {
		// check the number of the arguments
		if (longueur == 6) {
			f = new Forms(arg5);
			PDDocument doc = PDDocument.load(new File(arg5));
			int count = doc.getNumberOfPages();

			for (int i = 0; i < count; i++) {
				// numero_page=i, x=Integer.parseInt(arg1) ,y=Integer.parseInt(arg2),width=Integer.parseInt(arg3),   heigh=Integer.parseInt(arg4)
				f.tField(i, Integer.parseInt(arg1), Integer.parseInt(arg2), Integer.parseInt(arg3),
						Integer.parseInt(arg4));
 
			}
			System.out.println(" a TextField has been added to every single page  of the pdf");
			f.closePdf(arg5);
		} else
			System.out.println(" more or less arguments than expected");
	}
	//addTextFieldTo 1 2 50 50 140 180
	// C:\\Users\\admin\\Desktop\\mm.pdf
	static void afficherTextFieldTo(int longueur, String arg5, String arg1, String arg2, String arg3, String arg4,
			String arg6, String arg7) throws IOException {
		// check the number of the arguments
		if (longueur == 8) {
			f = new Forms(arg7);
			PDDocument doc = PDDocument.load(new File(arg7));
			int count = doc.getNumberOfPages();
			int firstpage = Integer.parseInt(arg1);
			int lastPage= Integer.parseInt(arg2);
			if (lastPage <= count) { 
				for (int i = firstpage; i <= lastPage; i++) {
				 
					// page=numero_page, x=Integer.parseInt(arg3) ,y=Integer.parseInt(arg4),width=Integer.parseInt(arg5),   heigh=Integer.parseInt(arg6)
					f.tField(i, Integer.parseInt(arg3), Integer.parseInt(arg4), Integer.parseInt(arg5),
							Integer.parseInt(arg6));

					System.out.println(" text field has been added from   page number"+arg1 +"to page number"+arg2+ "of the pdf");

				}
				f.closePdf(arg7);
			} else
				System.out.println("pdf only have " + count + " pages\n");
		} else
			System.out.println(" more or less arguments than expected");
	}
}
