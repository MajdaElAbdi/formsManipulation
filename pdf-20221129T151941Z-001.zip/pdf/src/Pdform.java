import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.pdfbox.pdmodel.PDDocument;

// this class has the main function of the Cli class
public class Pdform {
	Cli c = new Cli();

	public static void main(String[] args) throws IOException {
		// Forms f = new Forms();
		Cli c = new Cli();
		switch (args[0]) {

		case "help":
			c.help();
			break;
			//addCheckBox 0 70 245 3 C:\\Users\\admin\\Desktop\\formulaire.pdf
		// description des arguments: addCheckBox numero_de_page x y nombre_d_elements chemin_vers_pdf
			//ajouter un groupe de checkBox
		case "addCheckBox":
			//numero_page=Integer.parseInt(arg1), x=Integer.parseInt(arg2),y=Integer.parseInt(arg3), nombre_de_bouton=Integer.parseInt(arg4)
			c.afficherCheckbox(args.length, args[5], args[1], args[2], args[3], args[4]);
			break;
			
			
		// exemple des arguments: addRadioBox 0 100 500 4 C:\\Users\\admin\\Desktop\\kk.pdf t
		// description des arguments: addRadioBox numero_de_page x y nombre_d'elements
		// chemin_vers_pdf nom_du_groupe_des_bouttons
			//ajouter un groupe de RadioButton
		case "addRadioBox":
			//numero_page=Integer.parseInt(arg1),x=Integer.parseInt(arg2) ,y=Integer.parseInt(arg3),nombre_de_bouton=Integer.parseInt(arg4), ButtonGroupName=arg6
			c.afficherRadioBox(args.length, args[5], args[1], args[2], args[3], args[4], args[6]);
			break;
			
			
       //l'ajout d'un TextField � une page d'un Pdf
		// exemple des arguments: addTextField 0 50 50 140 180 C:\\Users\\admin\\Desktop\\mm.pdf
		// description des arguments: addTextField numero_de_page x y largeur longueur
		// chemin_vers_pdf
		case "addTextField":
// numero_page=Integer.parseInt(arg1), x=Integer.parseInt(arg2) ,y=Integer.parseInt(arg3),width=Integer.parseInt(arg4),heigh=Integer.parseInt(arg5)
			c.afficherTextField(args.length, args[5], args[1], args[2], args[3], args[4], args[6]);
			break;
			
			
			//ajouter un groupe de RadioButton dans chaque page de pdf
		// example des arguments: addRadioBoxAll 10 30 6 C:\\Users\\admin\\Desktop\\cc.pdf c
		// description des arguments: addRadioBoxAll x y nombre_d'elements
		// chemin_vers_pdf nom_du_groupe_des_bouttons
		case "addRadioBoxAll":
			//numero_page=i,x=Integer.parseInt(arg1) ,y=Integer.parseInt(arg2),nombre_de_bouton=Integer.parseInt(arg3), ButtonGroupName=arg5
			c.afficherRadioBoxAll(args.length, args[4], args[1], args[2], args[3], args[5]);
			break;
			 
		// exemple des arguments: addCheckBoxAll 40 80 6
		// C:\\Users\\admin\\Desktop\\bb.pdf
		// description des arguments: addCheckBoxAll x y nombre_d'elements chemin_vers_pdf
		// nom_du_groupe_des_bouttons
			//ajouter un groupe de  checkBox dans chaque page de pdf
		case "addCheckBoxAll":
			// numero_page=i, x=Integer.parseInt(arg1),y=Integer.parseInt(arg2), nombre_de_bouton=Integer.parseInt(arg3)
			c.afficherCheckBoxall(args.length, args[4], args[1], args[2], args[3]);
			break;
			
			//ajouter un  textfield dans chaque page de pdf
		// exemple des arguments: addTextFieldAll 50 50 140 180
		// C:\\Users\\admin\\Desktop\\mm.pdf
		// description des arguments: addTextField x y largeur longuer chemin_vers_pdf
		case "addTextFieldAll":
			// numero_page=i, x=Integer.parseInt(arg1) ,y=Integer.parseInt(arg2),width=Integer.parseInt(arg3),   heigh=Integer.parseInt(arg4)
			c.afficherTextFieldAll(args.length, args[5], args[1], args[2], args[3], args[4]);
			break;
		 
		// description des arguments: addCheckTo pagedebut pagefin x y nombre_d_elementschemin_vers_pdf
			// exemple des arguments: addCheckBoxTo 0 1 40 80 6 C:\\Users\\admin\\Desktop\\bb.pdf
		// addCheckTo ajoute un groupe de checkBox dans un intervalle de pages d'un pdf.  
		//EX: l'ajout d'un groupe de checkbox de la page deux � la page quatre
			
		case "addCheckBoxTo":
			// numero_page=i, x=Integer.parseInt(arg3),y=Integer.parseInt(arg4), nombre_de_bouton=Integer.parseInt(arg5)
			c.afficherCheckBoxTo(args.length, args[5], args[1], args[2], args[3], args[4], args[6]);
			break;

		// exemple des arguments: addTextFieldTo 1 2 50 50 140 180
		// C:\\Users\\admin\\Desktop\\mm.pdf
		// description des arguments: addTextFieldTo pagedebut pagefin largeur longueur
		// chemin_vers_pdf
			// addCheckTo ajoute TextField dans un intervalle de pages d'un pdf.  
			//EX: l'ajout d'un TextField de la page deux � la page quatre
		case "addTextFieldTo":
			// page=numero_page, x=Integer.parseInt(arg3) ,y=Integer.parseInt(arg4),width=Integer.parseInt(arg5),   heigh=Integer.parseInt(arg6)
			c.afficherTextFieldTo(args.length, args[5], args[1], args[2], args[3], args[4], args[6], args[7]);
			break;

		// exemple des arguments: addCombo 0 170 170 C:\\Users\\admin\\Desktop\\formulaire.pdf Maroc �gypte	�mirats �quateur �rythr�e Espagne Estonie �tats-Unis �thiopie Fidji Finlande France Gabon Gambie G�orgie
		// description des arguments: addCombo numero_de_page x y chemin_vers_pdf (les
		// valeurs des options de la liste d�roulante)

		case "addCombo":
			if (args.length > 6) {
				// checking the number of the arguments

				List<String> displayValues = new ArrayList<String>();
				// open the pdf
				// add a new form
				Forms f = new Forms(args[4]);

				// filling displayValues(an array list) with values from the args[] table
				// this list values will be options in our combobox
				for (int i = 5; i < args.length; i++) {
					String v = args[i];
					displayValues.add(v);
				}
				// adding a combobox to the form f
				// the combobox options are in diplayValues list
				f.combo(Integer.parseInt(args[1]), Integer.parseInt(args[2]), Integer.parseInt(args[3]), displayValues);
// close the pdf
				f.closePdf(args[4]);
				System.out.println(" combobox has been added to  page number"+args[1] +" of the pdf");
			} else {
				System.out.println("  less arguments than expected/n/nhhhh");
				c.help();
			}
			break;

		// exemple des arguments: addComboAll 50 50 140 180
		// C:\\Users\\admin\\Desktop\\mm.pdf nn kk ll
		// description des arguments: addCombo x y chemin_vers_pdf (les valeurs des
		// options de la liste d�roulante)
		case "addComboAll":
			// checking the number of the arguments
			if (args.length > 7) {
				// open the pdf
				// add a new form
				Forms f = new Forms(args[5]);
				//savoir le nombre de page dans le pdf 
				
				PDDocument doc = PDDocument.load(new File(args[5]));
				int count = doc.getNumberOfPages();
				List<String> displayValues = new ArrayList<String>();
				// filling displayValues(an array list) with values form the args[] table
				// this list values will be options in our combobox
				for (int i = 6; i < args.length; i++) {
					String v = args[i];
					displayValues.add(v);
				}
				// adding combobox to every page in the pdf
				// the combobox options are in diplayValues list
				for (int j = 0; j < count; j++) {
					f.combo(j, Integer.parseInt(args[1]), Integer.parseInt(args[2]), displayValues);

				}
				System.out.println(" combobox has been added to every single page of the pdf");
				//close the pdf
				f.closePdf(args[5]);
			} else {
				System.out.println(" more or less arguments than expected\n\n");
				c.help();
			}
			break;
			// raname the pdf 
		case "changeTitle":
			if (args.length == 3) {
				//open the pdf
				Forms f = new Forms(args[2]);
				// change the name 
				f.changeTitle(args[1]);
				System.out.println(" out");
				//close the pdf
				f.closePdf(args[2]);
			} else {
				System.out.println(" more or less arguments than expected\n\nnhhhh");
				c.help();
			}
			break;
			// change the name of the author
		case "changeAuthor":
			if (args.length == 3) {
				//open the pdf and create new form
				Forms f = new Forms(args[2]);
				f.changeAuthor(args[1]);
				//close the pdf
				f.closePdf(args[2]);
				
			} else {
				System.out.println("more or less arguments than expected/n/nhhhh");
				c.help();
			}
			break;
			
			// if the first argument does not match any of the above cases, the help paragraph will appear.
		default:c.help();

		}
	}
}