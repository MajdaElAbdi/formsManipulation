package pdf;
import java.io.IOException;
import org.apache.pdfbox.cos.COSBase;
import org.apache.pdfbox.cos.COSDictionary;
import org.apache.pdfbox.cos.COSName;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.graphics.color.PDColor;
import org.apache.pdfbox.pdmodel.graphics.color.PDDeviceRGB;
import org.apache.pdfbox.pdmodel.interactive.annotation.PDAnnotationWidget;
import org.apache.pdfbox.pdmodel.interactive.annotation.PDAppearanceCharacteristicsDictionary;
import org.apache.pdfbox.pdmodel.interactive.annotation.PDAppearanceDictionary;
import org.apache.pdfbox.pdmodel.interactive.annotation.PDAppearanceEntry;
import org.apache.pdfbox.pdmodel.interactive.annotation.PDBorderStyleDictionary;
import org.apache.pdfbox.pdmodel.interactive.form.PDAcroForm;
import org.apache.pdfbox.pdmodel.interactive.form.PDCheckBox;

public class CheckBox
{
    public CheckBox(){
    }

   
     
    public   CheckBox (float x ,float y, String s, PDPage page, PDDocument document, PDAcroForm acroForm ) throws IOException{
       
   
    PDCheckBox checkbox = new PDCheckBox(acroForm);
 box(x,y,s,checkbox,page ,document,acroForm);        
   
   
   
    }
         public static  void box(float x ,float y, String s,PDCheckBox checkbox, PDPage page, PDDocument document, PDAcroForm acroForm ) throws IOException{
           
            PDRectangle rect = new PDRectangle(x, PDRectangle.A4.getHeight() - 250-y,30, 30);
           
            checkbox.setPartialName(s);
            PDAnnotationWidget widget = checkbox.getWidgets().get(0);
            widget.setPage(page);
            widget.setRectangle(rect);
            widget.setPrinted(true);
           
           PDAppearanceCharacteristicsDictionary appearanceCharacteristics = new PDAppearanceCharacteristicsDictionary(new COSDictionary());
            appearanceCharacteristics.setBorderColour(new PDColor(new float[]{0, 0, 0}, PDDeviceRGB.INSTANCE));
            appearanceCharacteristics.setBackground(new PDColor(new float[]{1, 1, 0}, PDDeviceRGB.INSTANCE));
            // 8 = cross; 4 = checkmark; H = star; u = diamond; n = square, l = dot
            appearanceCharacteristics.setNormalCaption("4");
            widget.setAppearanceCharacteristics(appearanceCharacteristics);
           
      /*      PDBorderStyleDictionary borderStyleDictionary = new PDBorderStyleDictionary();
            borderStyleDictionary.setWidth(1);
            borderStyleDictionary.setStyle(PDBorderStyleDictionary.STYLE_SOLID);
            widget.setBorderStyle(borderStyleDictionary);
      */   
           PDAppearanceDictionary ap = new PDAppearanceDictionary();
            widget.setAppearance(ap);
            PDAppearanceEntry normalAppearance = ap.getNormalAppearance();
           
        /*    COSDictionary normalAppearanceDict = new COSDictionary();
            normalAppearance.getCOSObject();
            normalAppearanceDict.setItem(COSName.Off, createAppearanceStream(document, widget, false));
            normalAppearanceDict.setItem(COSName.YES, createAppearanceStream(document, widget, true));
        */   
           
            page.getAnnotations().add(checkbox.getWidgets().get(0));
            acroForm.getFields().add(checkbox);
            checkbox.unCheck();
            
        }



		private static COSBase createAppearanceStream(PDDocument document, PDAnnotationWidget widget, boolean b) {
			return null;
		}
}