package pdf;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.io.File;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.interactive.form.PDAcroForm;

public class Cli {
	static Forms f = new Forms();

	public Cli()
{}
	 
	// method

//help1
	public static void help() {
		System.out.println("pdform <option> <option parameteres> <pdf path> \n" + "possible options include : \n"
				+ "addTextField int(pageNumber) int(x) int(y)  int(width) int(height) string(path) \n"
				+ "addCheckBox int(pageNumber) int(x) int(y) int(nbrButton)  string(path)\n"
				+ "addRadioButton int(pageNumber) int(x) int(y) int(totalButtonNum) string(path) \n"
				+ "addCombo int(pageNumber) int(x) int(y) int( nbr de ligne de la liste combo) string(path) \n"
				+ "note : Measurement units inside a PDF are in points \n" + "700 \n" + "| \n" + "| pdf page dim\n"
				+ "| \n" + "0------600 \n");
	}

	static void afficherCheckbox(int longueur, String arg5, String arg1, String arg2, String arg3, String arg4)
			throws IOException {
		if (longueur == 6) {
			f = new Forms(arg5);

			f.checkBox(Integer.parseInt(arg1), Integer.parseInt(arg2), Integer.parseInt(arg3), Integer.parseInt(arg4));
			f.closePdf(arg5);
		}
		if (longueur < 6)
			System.out.println("less arguments than expected (checkBox)");
		if (longueur > 6)
			System.out.println(" more arguments than expected (checkBox)");
	}

	static void afficherRadioBox(int longueur, String arg5, String arg1, String arg2, String arg3, String arg4,
			String arg6) throws IOException {

		if (longueur == 7) {
			f = new Forms(arg5);
			f.radioButton(Integer.parseInt(arg1), Integer.parseInt(arg2), Integer.parseInt(arg3),
					Integer.parseInt(arg4), arg6);
			f.closePdf(arg5);
			System.out.println("goooooooooooooooooooooood");
		} else
			System.out.println(" more or less arguments than expected");
	}

	static void afficherRadioBoxAll(int longueur, String arg5, String arg1, String arg2, String arg3, String arg4,
			String arg6) throws IOException {
		if (longueur == 7) {
			f = new Forms(arg5);
			PDDocument doc = PDDocument.load(new File(arg5));
			int count = doc.getNumberOfPages();

			for (int i = 0; i < count; i++) {

				f.radioButton(i, Integer.parseInt(arg2), Integer.parseInt(arg3), Integer.parseInt(arg4), arg6);

				System.out.println("goooooooooooooooooooooood");
			}
			f.closePdf(arg5);
		} else
			System.out.println(" more or less arguments than expected");
	}

	static void afficherCheckBoxall(int longueur, String arg5, String arg1, String arg2, String arg3, String arg4)
			throws IOException {
		if (longueur == 6) {
			f = new Forms(arg5);
			PDDocument doc = PDDocument.load(new File(arg5));
			int count = doc.getNumberOfPages();

			for (int i = 0; i < count; i++) {

				f.checkBox(i, Integer.parseInt(arg2), Integer.parseInt(arg3), Integer.parseInt(arg4));

				System.out.println("goooooooooooooooooooooood");
			}
			f.closePdf(arg5);
		} else
			System.out.println(" more or less arguments than expected");
	}

	static void afficherCheckBoxTo(int longueur, String arg5, String arg1, String arg2, String arg3, String arg4,
			String arg6) throws IOException {
		if (longueur == 7) {
			f = new Forms(arg6);
			int a = Integer.parseInt(arg1);
			int b = Integer.parseInt(arg2);
			for (int i = a; i <= b; i++) {

				f.checkBox(i, Integer.parseInt(arg3), Integer.parseInt(arg4), Integer.parseInt(arg5));

				System.out.println("goooooooooooooooooooooood");
			}
			f.closePdf(arg6);
		} else
			System.out.println(" more or less arguments than expected");
	}

	static void afficherTextField(int longueur, String arg5, String arg1, String arg2, String arg3, String arg4,
			String arg6) throws IOException {
		if (longueur == 7) {
			f = new Forms(arg6);
			f.tField(Integer.parseInt(arg1), Integer.parseInt(arg2), Integer.parseInt(arg3), Integer.parseInt(arg4),
					Integer.parseInt(arg5));
			f.closePdf(arg6);
		} else
			System.out.println(" more or less arguments than expected");
	}

	static void afficherTextFieldAll(int longueur, String arg5, String arg1, String arg2, String arg3, String arg4)
			throws IOException {
		if (longueur == 6) {
			f = new Forms(arg5);
			PDDocument doc = PDDocument.load(new File(arg5));
			int count = doc.getNumberOfPages();

			for (int i = 0; i < count; i++) {

				f.tField(i, Integer.parseInt(arg1), Integer.parseInt(arg2), Integer.parseInt(arg3),
						Integer.parseInt(arg4));

				System.out.println("goooooooooooooooooooooood");
			}
			f.closePdf(arg5);
		} else
			System.out.println(" more or less arguments than expected");
	}

	static void afficherTextFieldTo(int longueur, String arg5, String arg1, String arg2, String arg3, String arg4,
			String arg6, String arg7) throws IOException {

		if (longueur == 8) {
			f = new Forms(arg7);
			PDDocument doc = PDDocument.load(new File(arg7));
			int count = doc.getNumberOfPages();
			int j = Integer.parseInt(arg2);
			int k = Integer.parseInt(arg1);
			if (j <= count) {
				for (int i = k; i <= j; i++) {
					f.tField(i, Integer.parseInt(arg3), Integer.parseInt(arg4), Integer.parseInt(arg5),
							Integer.parseInt(arg6));

					System.out.println("goooooooooooooooooooooood");

				}
				f.closePdf(arg7);
			} else
				System.out.println("pdf only have " + count + " pages\n");
		} else
			System.out.println(" more or less arguments than expected");
	}
}
