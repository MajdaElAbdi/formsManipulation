package pdf;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.pdfbox.pdmodel.PDDocument;

public class Pdform {
	Cli c= new Cli();
	public static void main(String[] args)  throws IOException {
			// Forms f = new Forms();
		Cli c= new Cli();
	// affichage des methodes possibles
	 	 			if (args.length == 1)
				c.help();

			// addCheckBox
	// example des arguments: 	addCheckBox 0 100 50 4   C:\\Users\\admin\\Desktop\\mm.pdf
			if (args[0].equals("addCheckBox"))
				c.afficherCheckbox(args.length, args[5], args[1], args[2], args[3], args[4]);

			// addRadioBox
			// example des arguments: addRadioBox 0 100 500 4
			// C:\\Users\\admin\\Desktop\\mm.pdf t
			if (args[0].equals("addRadioBox"))
				c.afficherRadioBox(args.length, args[5], args[1], args[2], args[3], args[4], args[6]);

			// addRadioBoxAll
			// example des arguments: addRadioBoxAll 0 10 30 6
			// C:\\Users\\admin\\Desktop\\cc.pdf c

			if (args[0].equals("addRadioBoxAll"))
				c.afficherRadioBoxAll(args.length, args[5], args[1], args[2], args[3], args[4], args[6]);

			// addCheckBoxall 
			//addCheckBoxall 0 40 80 6 C:\\Users\\admin\\Desktop\\bb.pdf
			if (args[0].equals("addCheckBoxall"))
				c.afficherCheckBoxall(args.length, args[5], args[1], args[2], args[3], args[4]);

			// addCheckBoxTo 0 1 40 80 6 C:\\Users\\admin\\Desktop\\bb.pdf
			if (args[0].equals("addCheckBoxTo"))
				c.afficherCheckBoxTo(args.length, args[5], args[1], args[2], args[3], args[4], args[6]);

			// addTextFieldAll
			// example des arguments: addTextFieldAll 50 50 140 180
			// C:\\Users\\admin\\Desktop\\mm.pdf
			// C:\\Users\\admin\\Desktop\\mm.pdf
			if (args[0].equals("addTextFieldAll"))
				c.afficherTextFieldAll(args.length, args[5], args[1], args[2], args[3], args[4]);

			// addTextField
			// example des arguments: addTextField 0 50 50 140 180
			// C:\\Users\\admin\\Desktop\\mm.pdf
			if (args[0].equals("addTextField"))
				c.afficherTextField(args.length, args[5], args[1], args[2], args[3], args[4], args[6]);

			// addTextFieldTo
			// addTextFieldTo 1 2 50 50 140 180 C:\\Users\\admin\\Desktop\\mm.pdf
			if (args[0].equals("addTextFieldTo"))
				c.afficherTextFieldTo(args.length, args[5], args[1], args[2], args[3], args[4], args[6], args[7]);

			// addComboTo 1 3 50 50 C:\\Users\\admin\\Desktop\\mm.pdf nn kk ll
			/*
			 * if (args[0].equals("addComboTo")) { if (args.length >= 7) { f = new
			 * Forms(args[5]); PDDocument doc = PDDocument.load(new File(args[5])); int
			 * count = doc.getNumberOfPages(); int n = args.length; int
			 * j=Integer.parseInt(args[2]); if(j<=count) { int k=Integer.parseInt(args[1]);
			 * List<String> displayValues = new ArrayList<String>(); int i=0; String v="";
			 * System.out.println(args.length); for ( i = 6; i < n; i++) { v = args[i];
			 * System.out.println(args[i]); displayValues.add(v); }
			 * 
			 * for ( i = k; i <= j; i++) { f.combo( j, Integer.parseInt(args[3]),
			 * Integer.parseInt(args[4]), displayValues);
			 * System.out.println("goooooooooooooooooooooood"); } f.closePdf(args[5]); }
			 * else System.out.println("pdf only have " +count+ " pages\n"); } else
			 * System.out.println(" more or less arguments than expected"); }
			 */

			// ex addCombo 0 50 50 C:\\Users\\admin\\Desktop\\mm.pdf
			if (args[0].equals("addCombo"))
				if (args.length > 7) {
					System.out.println(args.length);
					int n = args.length;
					System.out.println(n);
					List<String> displayValues = new ArrayList<String>();
				Forms	f = new Forms(args[5]);
					for (int i = 6; i < n; i++) {
						String v = args[i];
						displayValues.add(v);
					}

					f.combo(Integer.parseInt(args[1]), Integer.parseInt(args[2]), Integer.parseInt(args[3]), displayValues);

					f.closePdf(args[5]);
				} else
					System.out.println("more or less arguments than expected");
			// addComboAll
			// example des arguments: addComboAll 50 50 140 180
			// C:\\Users\\admin\\Desktop\\mm.pdf nn kk ll

			if (args[0].equals("addComboAll")) {
				if (args.length > 7) {
				Forms	f = new Forms(args[5]);
					PDDocument doc = PDDocument.load(new File(args[5]));
					int count = doc.getNumberOfPages();
					int n = args.length;
					List<String> displayValues = new ArrayList<String>();
					for (int i = 6; i < n; i++) {
						String v = args[i];
						displayValues.add(v);
					}
					for (int j = 0; j < count; j++) {
						f.combo(j, Integer.parseInt(args[1]), Integer.parseInt(args[2]), displayValues);
						System.out.println("goooooooooooooooooooooood");
					}
					f.closePdf(args[5]);
				} else
					System.out.println(" more or less arguments than expected");
			}
			// changeTitle changeTitle hiiiiiiii C:\\Users\\admin\\Desktop\\bb.pdf
			if (args[0].equals("changeTitle")) {
				if (args.length == 3) {
				Forms	f = new Forms(args[2]);
					f.changeTitle(args[1]);
					System.out.println(" out");
					f.closePdf(args[2]);
				} else
					System.out.println(" more or less arguments than expected");
			}

			// changeAuthor
			if (args[0].equals("changeAuthor")) {
				if (args.length == 3) {
			Forms		f = new Forms(args[2]);
					f.changeAuthor(args[1]);
					f.closePdf(args[2]);
				} else
					System.out.println(" more or less arguments than expected");
			}

		}


	}


