package pdf;
import java.io.File;
 
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

//import org.apache.pdfbox.cos.COSDictionary;
import org.apache.pdfbox.cos.COSName;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDResources;
//import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDFont;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
/*import org.apache.pdfbox.pdmodel.graphics.color.PDColor;
import org.apache.pdfbox.pdmodel.graphics.color.PDDeviceRGB;
import org.apache.pdfbox.pdmodel.interactive.annotation.PDAnnotationWidget;
import org.apache.pdfbox.pdmodel.interactive.annotation.PDAppearanceCharacteristicsDictionary;
*/
import org.apache.pdfbox.pdmodel.interactive.form.PDAcroForm;
//import org.apache.pdfbox.pdmodel.interactive.form.PDTextField;
import org.apache.pdfbox.pdmodel.PDDocumentInformation;
public class Forms {
	public String path;
	PDDocument document;
	PDAcroForm form;
		
	// creat a new pdf 
		public  Forms() {
		 //Creating PDF document object
		     this.document = new PDDocument();

		 //Creating a blank page
		     PDPage blankPage = new PDPage();
		       
		 //Adding the blank page to the document
		     document.addPage( blankPage );
		      
		 //creat an Acroform
		     this.creatAcro();
			
		}
		
	
		public Forms(String path) throws IOException {
			 //test for pdf extension
				if(!path.endsWith(".pdf")) {
					System.out.println("this file is not a pdf \n");
					
					return;
				}
			 
			 //test if file exist
				File file = new File(path);
				if(!file.exists()) {
					
					System.out.println("unvalide path ; file not found \n ");
					System.out.println(" new pdf will be created \n ");
					document = new PDDocument ();
					document.addPage(new PDPage());
					document.addPage(new PDPage());
					document.addPage(new PDPage());
					document.save (path);
					document.close ();
					}
				else System.out.println(" file found \n ");
				
 
			  //open document
				this.path = path;
		        this.document = PDDocument.load(file);
		    	
		      //creat an Acroform
		        this.creatAcro();
				
			}
	//Open an existing pdf
	/*	public Forms(String path) throws IOException {
		 //test for pdf extension
			if(!path.endsWith(".pdf")) {
				System.out.println("this file is not a pdf \n");
				return;
			}
		 
		 //test if file exist
			File file = new File(path);
			if(!file.exists()) {
				System.out.println("unvalide path ; file not found \n ");
				return;
			}
			
		  //open document
			this.path = path;
	        this.document = PDDocument.load(file);
	    	
	      //creat an Acroform
	        this.creatAcro();
			
		}
		*/
	//close an existing pdf
		public void closePdf() throws IOException  {
			
			if(path == null) {
				System.out.println("Enter a path to save the new pdf \n");
			}
			this.document.save(this.path);
	        this.document.close();
		}
		
	//close a new pdf 
		public void closePdf(String path) throws IOException  {
			this.path = path;
			this.document.save(this.path);
	        this.document.close();
		}
		
	//creat an Acroform
		public void creatAcro() {
			form = new PDAcroForm(document);
			document.getDocumentCatalog().setAcroForm(form);

        //Setting default resources for the form
			PDFont font = PDType1Font.HELVETICA;
			PDResources resources = new PDResources();
			resources.put(COSName.getPDFName("Helv"), font);
			form.setDefaultResources(resources);
			
		}
	
	
	  //call textFeild	
		public void tField(int page, int x ,int y,int width, int height) throws IOException {
			TextField t= new TextField(page,x ,y,width,height ,document,form);
			t.makeTA();
		}
			
	  //call checkBox
		public void checkBox(int page, float x ,float y, int n  ) throws IOException {
			for(int i=0;i<n;i++) 
			new CheckBox(x,y-i*50,"n"+i,document.getPage(page),document,form);
			
		}
			
	  //call radio button 
		public void radioButton(int page, int x ,int y,int j, String t) throws IOException {
			List<String> option = new ArrayList<String>();
			for(int i=0;i<j;i++) {
	        	String s = "T"+i;
	        	option.add(s);
	        }
			RadioBox r=new RadioBox() ;
			r.createRadio(form, document, option,document.getPage(page),x,y,t);
		}
		
		
		public void changeTitle(String s) {
			 
			PDDocumentInformation pdd = document.getDocumentInformation();
			pdd.setTitle(s);
		 
			}
		public void  combo(int page, int x ,int y,List<String> displayValues) throws IOException {
			/*	List<String> option = new ArrayList<String>();
			List<String> f = new ArrayList<String>();
		 	for(int i=0;i<n;i++) {
	        	String s = "T"+i;
	        	String  v= "c"+i;
	        	option.add(s);
	        	f.add(v);
	       } */ 
	 Combo r=new  Combo() ;
	 
			r.createC(displayValues, displayValues, document,document.getPage(page), form); 
			System.out.println("done");
			
			}
		public void changeAuthor(String s) {
			PDDocumentInformation pdd = document.getDocumentInformation();
			pdd.setAuthor(s);
			}
		
}
